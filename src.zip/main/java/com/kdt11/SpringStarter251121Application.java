package com.kdt11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringStarter251121Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringStarter251121Application.class, args);
	}

}
