package com.kdt11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringStarter251121ApplicationTests {

	@Test
	void contextLoads() {
	}

}
